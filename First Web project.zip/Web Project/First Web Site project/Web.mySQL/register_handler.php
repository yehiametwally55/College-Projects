<?php
$firstName = $_POST["firstName"];
$lastName = $_POST["lastName"];
$email = $_POST["email"];
$password = $_POST["password"];
$age = $_POST["age"];
$mobile = $_POST["mobile"];
$car = $_POST["Car"];


include "config.php";

$insertUser = "INSERT INTO clients(FirstName,LastName,Email,Password,age,mobile ,Car)
values('$firstName','$lastName','$email','$password','$age','$mobile' , '$car')";

$result = mysqli_query($con,$insertUser);
if($result){
	
header('Location: HomePage.php');
}
else {
	echo "Error:".mysqli_error($con);
}

?>