<html>
<head>
	<title>Registration</title>
	<meta charset="UTF-8" />
	 <link rel="stylesheet" href="styles/style.css">
	<script src="js/script_regValidation.js"></script>
	 <script src="js/Myscript.js"></script>
			 <style>
		 
		  .des input{
			
			  background-color: white;
			  border: none;
			  color: black;
			  padding: 16px 32px;
			  text-decoration: none;
			  margin: 4px 2px;
			  cursor: pointer;
		}
		</style>
</head>

<body>

	 
    <div class="banner" >
         <button onclick="redirect()" ; class="header_btn" >Opel Since 1899</button>
		 </div>
	 <br>
<div  style=" text-align:Center ; width:550px ; background-color:#a30308 ; position:center ; borde0r: 2px outset black ; font-family:verdana ; font-size:100% ; margin:auto ; border-radius:10px ; ">
  <h2>Registration</h2>
  <form class="des" onsubmit="return validation()" method="post" name="regForm" action="register_handler.php">
		<label>First Name: *</label></br>
		<input type="text" name="firstName" placeholder="Your First Name" size="25" /></br>
		<label>Last Name: *</label></br>
		<input type="text" name="lastName" placeholder="Your Last Name" size="25" /></br>
		<label>Email: *</label></br>
		<input type="text" name="email" size="25" placeholder="Your Email" /></br>
		<label>Password: *</label></br>
		<input type="password" name="password" placeholder="Your Password" size="25" /></br>
		<label>Age:</label></br>
		<input type="text" name="age" size="25" placeholder="Your Age" /></br>
		<label>Mobile:</label></br>
		<input type="text" name="mobile" size="25" placeholder="Your Mobile" /></br></br>
		<label>Your car:</label></br>
		<input type="text" name="Car" size="25" placeholder="Your car" /></br></br>
		<a href = "Login.php" style="color:white">already have an account? Login</a>
		<div align="center">
		<input type="submit" value="Register" />
		<input type="reset" value="Clear"  />
		</div>
  </form>
</div>

<div class="footer">
  <h1>&copy; Opel</h1>
</div>
 </body>

</body>

</html>