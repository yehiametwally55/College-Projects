<?php

$selected_val= $_POST['carModel']; 
$date = $_POST['serviceDate'];
$store = $_POST['store'];

include "config.php";

$book = "INSERT INTO service(carModel,date , store ) values('$selected_val' ,'$date','$store')";

$result = mysqli_query($con,$book);
if($result){
	
	header('Location: HomePage.php');
}
else{
	echo "Error:".mysqli_error($con);
}

?>