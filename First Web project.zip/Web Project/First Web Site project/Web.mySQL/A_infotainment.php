<!DOCTYPE html>
<html>

     <head>
		 <title> Opel-8 intellink-infotainment </title>
		 <meta charset="UTF-8">
		 <meta name="viewport" content="width=device-width, initial-scale:1.0">
		 <link rel="stylesheet" href="styles/style.css">
		 <script src="js/Myscript.js"></script>
		 
		 <style>
			
		 </style>
     </head>
	 

 <body>
 
      <div class="imgmenu">
     <img src="images/menu.png" width="30px" onclick="openMenu();">
	 </div>
	 <div id="sideMenu" >
		 <ul>
		     <li><a href="#" class="closeBtn" onclick="closeMenu();">&times;</a></li>
		     <li><a href="HomePage.php">Home</a></li>
		     <li><a href="corsa.php">Corsa</a></li>
			 <li><a href="astra.php">Astra</a></li>
			 <li><a href="grandland.php">GrandLand</a></li>
			 <li><a href="concept.php">opel concept</a></li>
			 <li><a href="book.php">book your car</a></li>
			 <li><a href="service.php">service</a></li>
			 <li><a href="about_us.php">About Us</a></li>
			 <li><a href="register.php">Register</a></li>
			 </ul>
	 </div>
    <div class="banner" >
         <button onclick="redirect()" ; class="header_btn" >Opel Since 1899</button>
	</div>
		 <div id="menu" >
		 <ul>
		     <li><a href="HomePage.php">Home</a></li>
		     <li><a href="corsa.php">Corsa</a></li>
			 <li><a href="astra.php">Astra</a></li>
			 <li><a href="grandland.php">GrandLand</a></li>
			 <li><a href="concept.php">opel concept</a></li>
			 <li><a href="book.php">book your car</a></li>
			 <li><a href="service.php">service</a></li>
			 <li><a href="about_us.php">About Us</a></li>
			 </ul>
		 </div>	
		
	 <div >
		<div class="screen";style="background-color:#a30308;margin:auto;border:2px outset white;width:80%;">
	     <h2 style="color:white"> 8 INCH SCREEN </h2>
		 <img src="images/A2_infotainment.jpg" width=580px>
		 <p style="color:white">screen text screen text screen text screen text</p>
		 <div data-aos="zoom-in"></div>
	 </div>
	 
	 <div class="speaker";style="margin:auto;border:2px outset white;width:80%;">
	     <h2 style="color:black"> 8 SPEAKERS SOUND SYSTEM </h2>
		 <img src="images/A_speaker.jpg" width=580px>
		 <p style="color:black">speakers text speakers text speakers text speakers text </p>
	 </div>
	 
	 <div class="nav";style="background-color:#a30308;margin:auto;border:2px outset white;width:80%;">
	     <h2 style="color:white"> NAVIGATION </h2>
		 <img src="images/A_navi.jpg" width=580px>
		 <p style="color:white">navigation text navigation text navigation text navigation text</p>
	 </div>
	 
	 <div class="carplay";style="margin:auto;border:2px outset white;width:80%;">
	     <h2 style="color:black"> APPLE CARPLAY & ANDROID AUTO </h2>
		 <img src="images/A_carplay.jpg" width=580px>
		 <p style="color:black">carplay text carplay text carplay text carplay text </p>
	 </div>
	 </div>
	 	 
<div class="footer">
  <h1>&copy; Opel</h1>
</div>
 
	 </body>
</html>