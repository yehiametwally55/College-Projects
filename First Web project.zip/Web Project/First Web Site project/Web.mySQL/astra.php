<!DOCTYPE html>
<html>

     <head>
		 <title> Opel-Astra </title>
		 <meta charset="UTF-8">
		 <meta name="viewport" content="width=device-width, initial-scale:1.0">
		 <link rel="stylesheet" href="styles/style.css">
		 <script src="js/Myscript.js"></script>
     </head>

 <body>
 
      <div class="imgmenu">
     <img src="images/menu.png" width="30px" onclick="openMenu();">
	 </div>
	 <div id="sideMenu" >
		 <ul>
		     <li><a href="#" class="closeBtn" onclick="closeMenu();">&times;</a></li>
		     <li><a href="HomePage.php">Home</a></li>
		     <li><a href="corsa.php">Corsa</a></li>
			 <li><a href="astra.php">Astra</a></li>
			 <li><a href="grandland.php">GrandLand</a></li>
			 <li><a href="concept.php">opel concept</a></li>
			 <li><a href="book.php">book your car</a></li>
			 <li><a href="service.php">service</a></li>
			 <li><a href="about_us.php">About Us</a></li>
			 <li><a href="register.php">Register</a></li>
			 </ul>
	 </div>
	 
    <div class="banner" >
          <button onclick="redirect()" ; class="header_btn" >Opel Since 1899</button>
	</div>
		 <div id="menu" >
		 <ul>
		     <li><a href="HomePage.php">Home</a></li>
		     <li><a href="corsa.php">Corsa</a></li>
			 <li><a href="astra.php">Astra</a></li>
			 <li><a href="grandland.php">GrandLand</a></li>
			 <li><a href="concept.php">opel concept</a></li>
			 <li><a href="book.php">book your car</a></li>
			 <li><a href="service.php">service</a></li>
			 <li><a href="about_us.php">About Us</a></li>
			 </ul>
		 </div>	
	 <div>	 
	 <div style="background-color:#a30308;margin:auto;border:2px outset white;text-align:center;">
		 <img src="images/astra.jpg" width=860px>
	 </div>
	 <div class="interior2">
	     <h2 style="color:black"> INTERIOR </h2>
		 <img src="images/astraint.jpg" width=580px>
		 <p style="color:black">Interior text Interior text Interior text Interior text</p>
	 </div>
	 <div class="exterior2">
	     <h2 style="color:white"> EXTERIOR </h2>
		 <img src="images/astraext.jpg" width=580px>
		 <p>Exterior text Exterior text Exterior text Exterior text</p>
	 </div>
	 <div class="power2">
	     <h2 style="color:black"> POWER & <br> PERFORMANCE </h2>
		 <img src="images/motor.jpg" width=580px>
		 <p style="color:black">Performance text Performance text Performance text Performance text</p>
	 </div>
	 <div class="infotainment2">
	     <h2 style="color:white">INFOTAINMENT</h2>
		 <img src="images/A2_infotainment.jpg" width=580px>
		 <p>Performance text Performance text Performance text Performance text <br> <a href="A_infotainment.html"> learn more </a> </p>
	 </div>
	 </div>
	 	 
 <div class="footer">
  <h1>&copy; Opel</h1>
</div>
 
 </body>
</html>