<?php
$email = $_POST["email"];
$password = $_POST["password"];

include "config.php";

$Login = " SELECT Email , Password FROM clients WHERE Email = '$email' and Password = '$password'";

$result = mysqli_query($con,$Login);

$count = mysqli_num_rows($result);

if($count == 1){
	session_start();
	$_SESSION["loggedUser"] = $email;
	header('Location: UserProfile.php');
}

else {
	
	echo " invalid email and password";
}
?>