<!DOCTYPE html>
<html>

     <head>
		 <title> Opel-About Us </title>
		 <meta charset="UTF-8">
		 <meta name="viewport" content="width=device-width, initial-scale:1.0">
		 <link rel="stylesheet" href="styles/style.css">
		 <script src="js/Myscript.js"></script>
     </head>

 <body>
 
      <div class="imgmenu">
     <img src="images/menu.png" width="30px" onclick="openMenu();">
	 </div>
	 <div id="sideMenu" >
		 <ul>
		     <li><a href="#" class="closeBtn" onclick="closeMenu();">&times;</a></li>
		     <li><a href="HomePage.php">Home</a></li>
		     <li><a href="corsa.php">Corsa</a></li>
			 <li><a href="astra.php">Astra</a></li>
			 <li><a href="grandland.php">GrandLand</a></li>
			 <li><a href="concept.php">opel concept</a></li>
			 <li><a href="book.php">book your car</a></li>
			 <li><a href="service.php">service</a></li>
			 <li><a href="about_us.php">About Us</a></li>
			 <li><a href="register.php">Register</a></li>
			 </ul>
	 </div>
 
    <div class="banner" >
          <button onclick="redirect()" ; class="header_btn" >Opel Since 1899</button>
	</div>
		 <div id="menu" >
		 <ul>
		     <li><a href="HomePage.php">Home</a></li>
		     <li><a href="corsa.php">Corsa</a></li>
			 <li><a href="astra.php">Astra</a></li>
			 <li><a href="grandland.php">GrandLand</a></li>
			 <li><a href="concept.php">opel concept</a></li>
			 <li><a href="book.php">book your car</a></li>
			 <li><a href="service.php">service</a></li>
			 <li><a href="about_us.php">About Us</a></li>
			 </ul>
		 </div>	
	 <div>
	 <div style="margin:auto;text-align:center;">
		 <img src="images/about_us.jpg" width=860px> 
	 </div >
	 <div class="about_us">
	     <h1>About Us</h1>
		 <p><h1> yehia mohamed abdelaziz 18100473</h1><br>
		    <h1> amr mohamed el dakak 18100466</h1>  <br>
			About Us Text About Us Text About Us Text About Us Text About Us Text</p>
	 </div>
	</div>
	</div>
		 
 <div class="footer">
  <h1>&copy; Opel</h1>
</div>
 
 </body>
</html>