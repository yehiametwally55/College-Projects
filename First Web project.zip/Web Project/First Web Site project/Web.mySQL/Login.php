<html>
<head>
	<title>Login</title>
	<meta charset="UTF-8" />
	 <link rel="stylesheet" href="styles/style.css">
	<script src="js/MySciptLogin.js"></script>
	 
			 <style>
		 
		  .des input{
			
			  background-color: white;
			  border: none;
			  color: black;
			  padding: 16px 32px;
			  text-decoration: none;
			  margin: 4px 2px;
			  cursor: pointer;
		}
		</style>
</head>

<body>

    <div class="banner" >
         <button onclick="redirect()" ; class="header_btn" >The Gift Shop</button>
		 </div>
	 <br>
<div  style=" text-align:Center ; width:550px ; background-color:#a30308 ; position:center ; borde0r: 2px outset black ; font-family:verdana ; font-size:100% ; margin:auto ; border-radius:10px ; ">
  <h2>Login</h2>
  <form class="des" onsubmit="return validation()" method="post" name="regForm" action="Login_handler.php">
		
		<label>Email: *</label></br>
		<input type="text" name="email" size="25" placeholder="Your Email" /></br>
		<label>Password: *</label></br>
		<input type="password" name="password" placeholder="Your Password" size="25" /></br>
		
		<div align="center">
		<input type="submit" value="Login" />
		<input type="reset" value="Clear"  />
		</div>
  </form>
</div>

<div class="footer">
</div>
 </body>

</body>

</html>