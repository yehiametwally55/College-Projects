<?php

$selected_val= $_POST['carModel']; 
$city = $_POST['city'];


include "config.php";

$book = "INSERT INTO bookedcars(carModel,city ) values('$selected_val' ,'$city')";

$result = mysqli_query($con,$book);
if($result){
	
	header('Location: HomePage.php');
}
else{
	echo "Error:".mysqli_error($con);
}


?>