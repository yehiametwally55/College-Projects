<!DOCTYPE html>
<html>

<head>
	<title>Book your service</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale:1.0">
	<link rel="stylesheet" href="styles/style.css">
	<script src="js/Myscript.js"></script>
	
	<style>
		.decor select{
			  width:80%;
			  padding: 16px 20px;
			  border: none;
			  border-radius: 4px;
			  background-color: #f1f1f1;
		}
		.decor input{
			  background-color: white;
			  border: none;
			  color: black;
			  padding: 16px 32px;
			  text-decoration: none;
			  margin: 4px 2px;
			  cursor: pointer;
		}
	
	</style>
</head>

<body>
     <div class="imgmenu">
     <img src="images/menu.png" width="30px" onclick="openMenu();">
	 </div>
	 <div id="sideMenu" >
		 <ul>
		     <li><a href="#" class="closeBtn" onclick="closeMenu();">&times;</a></li>
		     <li><a href="HomePage.php">Home</a></li>
		     <li><a href="corsa.php">Corsa</a></li>
			 <li><a href="astra.php">Astra</a></li>
			 <li><a href="grandland.php">GrandLand</a></li>
			 <li><a href="concept.php">opel concept</a></li>
			 <li><a href="book.php">book your car</a></li>
			 <li><a href="service.php">service</a></li>
			 <li><a href="about_us.php">About Us</a></li>
			 <li><a href="register.php">Register</a></li>
			 </ul>
	 </div>
	 
    <div class="banner" >
          <button onclick="redirect()" ; class="header_btn" >Opel Since 1899</button>
		 </div>
		 <div id="menu" >
		 <ul>
		     <li><a href="HomePage.php">Home</a></li>
		     <li><a href="corsa.php">Corsa</a></li>
			 <li><a href="astra.php">Astra</a></li>
			 <li><a href="grandland.php">GrandLand</a></li>
			 <li><a href="concept.php">opel concept</a></li>
			 <li><a href="book.php">book your car</a></li>
			 <li><a href="service.php">service</a></li>
			 <li><a href="about_us.php">About Us</a></li>
			 </ul>
		 </div>
	 <br>
	 <div style="margin:auto;border:2px outset white;text-align:center;">
		 <img src="images/service.jpg" width=800px>
		 <br>
		<div class="decor"; style=" text-align:center; background-color:#a30308; border:5px outset black; width:800px; margin:auto ; position:center ;">
				<br>
			<form  method="post" name="serviceForm" action="service_handler.php" style="padding=10px";>
			  <label>choose the model</label></br>
			   <select name = "carModel">
			   <option value="Astra">Astra</option> 
			   <option value="grandland">grandland</option> 
			   <option value="Corsa">Corsa</option> 
			 
			   </select>
			   <br><br>
			   <label for="serviceDate" value="serviceDate">Date of service:</label>
				<input type="date" id="birthday" name="serviceDate">
				<br><br>
			   <label>choose the service center </label></br>
			   <select name = "store">
			   <option value="Smouha">Smouha</option>
			   <option value="Roshdy">roshdy</option>
			   <option value="san_stefano">san stefano</option>
			   <option value="5th_settelment">5th settelment</option>
			   </select>
			   <br>
			   <input type="submit" value="book" onclick ="book();" >
				<label id="Booking"style="color:black;"> </label>
				<br>
			   </form>
			   </div>
	  </div>
  
  <div class="footer">
  <h1>&copy; Opel</h1>
</div>

  </body>


</html>