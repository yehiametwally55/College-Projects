<?php

	session_start();
	if(!isset($_SESSION["loggedUser"])){
		header('Location: Login.php');		
	}
?>



<html>
<head>
	<title>Your profile</title>
	<meta charset="UTF-8"/>
	<style>
		label{
			font-weight: bold;
			color: red;
		}
	</style>
</head>

<body>
    
	 <?php
	 
	 include "config.php";
	 $email = $_SESSION["loggedUser"];
	 $viewUser = "SELECT * FROM clients WHERE Email = '$email'";
	 $result = mysqli_query($con , $viewUser);
	 if(!$result){
		 echo "error:".mysqli_error($con);
		 
	 }
	 $row = mysqli_fetch_array($result);
	 $FirstName =  $row["FirstName"];
	 $LastName=  $row["LastName"];
	 $age=  $row["age"];
	 $mobile=  $row["mobile"];
	 $car=  $row["Car"];
	 ?>
	 
	 <h1>Your profile</h1>
	 
	 <label>First Name:</label>
	 <p> <?php echo $FirstName?></p>
	 <label>Last Name:</label>
	 <p> <?php echo $LastName?></p>
	 <label>Email:</label>
	 <p> <?php echo $email?></p>
	 <label>age:</label>
	 <p> <?php echo $age?></p>
	 <label>mobile:</label>
	 <p><?php echo $mobile?></p>
	 <label>your car :</label>
	 <p><?php echo $car?></p>
	 
	 <a href ="logout.php">logout</a>
	 <a href ="service.php">book a service</a>
	 
<div class="footer">
  <h1>&copy; Opel</h1>
</div>
 </body>

</body>

</html>

