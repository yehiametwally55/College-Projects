<!DOCTYPE html>
<html>

     <head>
		 <title> Opel-Home </title>
		 <meta charset="UTF-8">
		 <meta name="viewport" content="width=device-width, initial-scale:1.0">
		 <link rel="stylesheet" href="styles/style.css">
		 <script src="js/Myscript.js"></script>
		 <style>
		 
		  .des input{
			
			  background-color: white;
			  border: none;
			  color: black;
			  padding: 16px 32px;
			  text-decoration: none;
			  margin: 4px 2px;
			  cursor: pointer;
		}
		</style>
		 
     </head>

 <body>
     <div class="imgmenu">
     <img src="images/menu.png" width="30px" onclick="openMenu();">
	 </div>
	 <div id="sideMenu" >
		 <ul>
		     <li><a href="#" class="closeBtn" onclick="closeMenu();">&times;</a></li>
		     <li><a href="HomePage.php">Home</a></li>
		     <li><a href="corsa.php">Corsa</a></li>
			 <li><a href="astra.php">Astra</a></li>
			 <li><a href="grandland.php">GrandLand</a></li>
			 <li><a href="concept.php">opel concept</a></li>
			 <li><a href="book.php">book your car</a></li>
			 <li><a href="service.php">service</a></li>
			 <li><a href="about_us.php">About Us</a></li>
			 <li><a href="register.php">Register</a></li>
			 </ul>
	 </div>
 	
     <div class="banner" >
         <button onclick="redirect()" ; class="header_btn" >Opel Since 1899</button>
		 </div>
		 <div id="menuHome" >
		 <ul>
		     <li><a href="HomePage.php">Home</a></li>
		     <li><a href="corsa.php">Corsa</a></li>
			 <li><a href="astra.php">Astra</a></li>
			 <li><a href="grandland.php">GrandLand</a></li>
			 <li><a href="concept.php">opel concept</a></li>
			 <li><a href="book.php">book your car</a></li>
			 <li><a href="service.php">service</a></li>
			 <li><a href="about_us.php">About Us</a></li>
			 <li><a href="register.php">Register</a></li>
			 </ul>
		 </div>
     	 <div style="margin:auto;text-align:center;">
		 <img src="images/1.jpg" width="860px">
		 </div>
	
	<div style="text-align:Center;width:50%;background-color:#a30308;position:center ; border: 2px outset black;font-family:verdana;font-size:100%;margin:auto;border-radius:10px;" >
     <form class="des" onsubmit="return validation()" method="post" name="Support" action="Support_insert.php">
	     <h2> Support / Contact Us </h2>
         <label>First Name*: </label></br>	 
         <input type="text"  name="firstName" placeholder="Your First Name" size="25"   /></br>
		 <label>E-mail*: </label></br>
		 <input type="text" name="email" placeholder="Your Mail" size="25"  /></br>
		  <label>Phone: </label></br>
		 <input type="text" name="phone" placeholder=" Enter Your Number" size="25"  /></br>
		  <label>Address: </label></br>
		 <input type="text" name="address" placeholder=" Enter Your Address" size="25" /></br>
		  <label>Message: </label></br>
		 <textarea name="message" > </textarea></br>
		 <input type="submit" value="Done">
	</form>	 
	</div>	
	</div>
	  
	  
  <div class="footer">
  <h1>&copy; Opel</h1>
</div>
 </body>
 
</html>