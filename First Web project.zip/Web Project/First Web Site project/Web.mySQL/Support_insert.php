<?php
$firstName = $_POST["firstName"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$address = $_POST["address"];
$message = $_POST["message"];

include "config.php";

$insertSupport = "INSERT INTO support (firstName,email,phone,address,message) value('$firstName','$email','$phone','$address','$message')";
$result = mysqli_query($con,$insertSupport);
if($result){
	
	header('Location: HomePage.php');
}
else {
	die("Error: ".mysqli_errno($con));
}
?>