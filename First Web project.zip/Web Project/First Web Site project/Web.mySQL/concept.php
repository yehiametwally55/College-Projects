<!DOCTYPE html>
<html>

     <head>
		 <title> Opel-concept </title>
		 <meta charset="UTF-8">
		 <meta name="viewport" content="width=device-width, initial-scale:1.0">
		 <link rel="stylesheet" href="styles/style.css">
		 <script src="js/Myscript.js"></script>
		 
		 <style>
			.car{
				margin:auto;
				padding-top:10px;
				padding-bottom:20px;
				width:100%;
				border-radius:10px;
			}
			.car img{
				width:60%;
			}
			.flip-box{
				margin:auto;
				width:100%;
				border-radius:10px;
				border:2px outset gray;
			
				margin-bottom:20px;
				padding-top:10px;
				margin-top:10px;
			}
			.flip-box p{
				text-align: center;
				padding-right:100px;
			}
			.flip-box img{
				width:65%
			}
			.exterior{
				padding-top:10px;
				padding-bottom:10px;
				width:100%;
				border-radius:10px;
				margin:auto;
				margin-bottom:20px;
				margin-top:10px;
			}
			.exterior p{
				float:right;
				padding-right:60px;
				color:white;
			}
			img{
				opacity:1;
				transition:0.5s;
			}
			img:hover{
				opacity:0.9;
				transition:0.5s;
			}
			
			.flip-box {
			  background-color: black ;
			  width: 80%;
			  height: 400px;
			  border: 1px solid #51a8f5;
			  perspective: 1000px;
			  
             }

			.flip-box-inner {
			  position: relative;
			  width: 100%;
			  height: 100%;
			  text-align: center;
			  transition: transform 0.8s;
			  transform-style: preserve-3d;
			  
			}

			.flip-box:hover .flip-box-inner {
			  transform: rotateY(180deg);
			  
			}

			.flip-box-front, .flip-box-back {
			  position: absolute;
			  width: 100%;
			  height: 100%;
			  -webkit-backface-visibility: hidden;
			  backface-visibility: hidden;
			  
			}

			.flip-box-front {
			  background-color:#0278ae ;
			  color: black;
			  
			}

			.flip-box-back {
			  background-color: dodgerblue;
			  color: white;
			  transform: rotateY(180deg);
			  
			}
		 </style>
     </head>

 <body>
      <div class="imgmenu">
     <img src="images/menu.png" width="30px" onclick="openMenu();">
	 </div>
	 <div id="sideMenu" >
		 <ul>
		     <li><a href="#" class="closeBtn" onclick="closeMenu();">&times;</a></li>
		     <li><a href="HomePage.php">Home</a></li>
		     <li><a href="corsa.php">Corsa</a></li>
			 <li><a href="astra.php">Astra</a></li>
			 <li><a href="grandland.php">GrandLand</a></li>
			 <li><a href="concept.php">opel concept</a></li>
			 <li><a href="book.php">book your car</a></li>
			 <li><a href="service.php">service</a></li>
			 <li><a href="about_us.php">About Us</a></li>
			 <li><a href="register.php">Register</a></li>
			 </ul>
	 </div>
    <div class="banner" >
          <button onclick="redirect()" ; class="header_btn" >Opel Since 1899</button>
	</div>
		 <div id="menu" >
		 <ul>
		     <li><a href="HomePage.php">Home</a></li>
		     <li><a href="corsa.php">Corsa</a></li>
			 <li><a href="astra.php">Astra</a></li>
			 <li><a href="grandland.php">GrandLand</a></li>
			 <li><a href="concept.php">opel concept</a></li>
			 <li><a href="book.php">book your car</a></li>
			 <li><a href="service.php">service</a></li>
			 <li><a href="about_us.php">About Us</a></li>
			 <li><a href="register.php">Register</a></li>
			 </ul>
		 </div>	
	 <div>	 
	 <div class="car"; style="background-color:#0278ae;margin:auto;border:2px outset white;text-align:center;">
		 <img src="images/concept1.jpg" width=860px>
	 </div>
	 <div class="flip-box";style="width=80%";>
		<div class="flip-box-inner">
			<div class="flip-box-front" style="background-color: white" ;>
	     <h2 style="color:black"> INTERIOR </h2>
		 <p style="color:black">Interior text Interior text Interior text Interior text</p>
		 </div>
		 <div class="flip-box-back">
		 <img src="images/concept3.jpg" width=580px>
		 
		 </div>
		 </div>
	 </div>
	 <div class="flip-box">
		<div class="flip-box-inner">
			<div class="flip-box-front">
				<h2 style="color:black"> EXTERIOR </h2>
				<p style="color:black; align:center;">Exterior text Exterior text Exterior text Exterior text</p>
			</div>
		<div class="flip-box-back">
		 <img src="images/concept2.jpg" width=780px>
		 
	 </div>
	 </div>
	 </div>
	 	 
 <div class="footer">
  <h1>&copy; Opel</h1>
</div>
 
 </body>
</html>