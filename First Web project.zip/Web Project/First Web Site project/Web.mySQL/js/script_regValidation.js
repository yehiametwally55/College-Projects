function validation(){
	
	var valid = true;
	
	formLabels = document.getElementsByTagName("label");
	
	var firstName = document.regForm.firstName.value;
	if(firstName==""){
		formLabels[0].innerHTML="First Name: [Required]";
		formLabels[0].style="color: white";
		valid = false;
	}
	else if( !isNaN(firstName)){
		formLabels[0].innerHTML="First Name: [Text Only]";
		formLabels[0].style="color: white";
		valid = false;
	}
	else {
		formLabels[0].innerHTML="First Name:";
		formLabels[0].style="color: black";
		valid = (valid) ? true : false;
	}
	
	var lastName = document.regForm.lastName.value;
	if(lastName==""){
		formLabels[1].innerHTML="Last Name: [Required]";
		formLabels[1].style="color: white";
		valid = false;
	}
	else if( !isNaN(lastName)){
		formLabels[1].innerHTML="Last Name: [Text Only]";
		formLabels[1].style="color: white";
		valid = false;
	}
	else {
		formLabels[1].innerHTML="Last Name:";
		formLabels[1].style="color: black";
		valid = (valid) ? true : false;
	}
	
	var email = document.regForm.email.value;
	var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	if(email==""){
		formLabels[2].innerHTML="Email: [Required]";
		formLabels[2].style="color: white";
		valid = false;
	}
	else if(!re.test(email)){
		formLabels[2].innerHTML="Email: [Incorrect Email]";
		formLabels[2].style="color: white";
		valid = false;
	}
	else {
		formLabels[2].innerHTML="Email:";
		formLabels[2].style="color: black";
		valid = (valid) ? true : false;
	}
	
	var password = document.regForm.password.value;
	if(password == ""){
		formLabels[3].innerHTML="Password: [Required]";
		formLabels[3].style="color: white";
		valid = false;
	}
	else if(password.length < 8){
		formLabels[3].innerHTML="Password: [Must be > 8]";
		formLabels[3].style="color: white";
		valid = false;
	}
	else {
		formLabels[3].innerHTML="Password:";
		formLabels[3].style="color: black";
		valid = (valid) ? true : false;
	}
	
		var age = document.regForm.age.value;
	if(age < 0 || age > 100){
		formLabels[4].innerHTML="Age: [Must be between 0 and 100]";
		formLabels[4].style="color: white";
		valid = false;
	}
	else if( isNaN(age)){
		formLabels[4].innerHTML="Age: [Age must be a number]";
		formLabels[4].style="color: white";
		valid = false;
	}
	else {
		formLabels[4].innerHTML="Age:";
		formLabels[4].style="color: black";
		valid = (valid) ? true : false;
	}
	
	var mobile = document.regForm.mobile.value;
	if( isNaN(mobile)){
		formLabels[5].innerHTML="Mobile: [Mobile  must be a number Only]";
		formLabels[5].style="color: white";
		valid = false;
	}
	else {
		formLabels[5].innerHTML="Mobile:";
		formLabels[5].style="color: black";
		valid = (valid) ? true : false;
	}
	
	return valid;
}
function redirect(){
	
	window.location.href = "HomePage.php";
}