function openMenu(){
	var menu = document.getElementById("sideMenu").style.width = "200px";
}

function closeMenu(){
	var menu = document.getElementById("sideMenu").style.width = "0";
}


function validation(){
	var valid = true;
	
	formLabels = document.getElementsByTagName("label");
	
	
	var firstName = document.getElementsByName("firstName")[0];
	
	if(firstName.value==""){
		formLabels[0].innerHTML="First Name*: [required]";
		formLabels[0].style="color: white";
		valid = false;
	}
	else if( !isNaN(firstName.value)){
		formLabels[0].innerHTML="First Name*: [Name must be a text only]";
		formLabels[0].style="color: white";
		valid = false;
	}
	else {
		formLabels[0].innerHTML="First Name:";
		formLabels[0].style="color: black";
		valid = (valid) ? true : false;
	}
	
	
		var email = document.getElementsByName("email")[0];
		
	if(email.value==""){
		formLabels[1].innerHTML="Email*: [required]";
		formLabels[1].style="color: white";
		valid = false;
	}
	else if(email.value.indexOf("@")==-1 || email.value.indexOf(".")==-1 || email.value.indexOf(".") < email.value.indexOf("@")==-1 ){
		formLabels[1].innerHTML="Email*: [Enter correct email]";
		formLabels[1].style="color: white";
		valid = false;
	}
	else {
		formLabels[1].innerHTML="Email:";
		formLabels[1].style="color: black";
		valid = (valid) ? true : false;
	}
	
	
		var phone = document.getElementsByName("phone")[0];
		
	if( isNaN(phone.value)){
		formLabels[2].innerHTML="Phone*: [Phone must be a number Only]";
		formLabels[2].style="color: white";
		valid = false;
	}
	else {
		formLabels[2].innerHTML="Phone:";
		formLabels[2].style="color: black";
		valid = (valid) ? true : false;
	}
	
	return valid;
}
window.onscroll = function() {PinMenu()};

function PinMenu() {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    document.getElementById("menu").style.fontSize = "15px";
	document.getElementById("menu").style.top = 0;
  } else {
    document.getElementById("menu").style.fontSize = "100%";
  }
}
function book(){
			document.getElementById("Booking").innerHTML ="your booking is confirmed";
			setTimeout(window.location.href = "HomePage.php" , 40000);
			
}
function redirect(){
	
	window.location.href = "HomePage.php";
}